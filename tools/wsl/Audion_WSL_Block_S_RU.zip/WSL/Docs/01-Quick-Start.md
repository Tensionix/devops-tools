# 01. Быстрый старт (S:\WSL)

## 1. Распаковка архива

Распакуй архив так, чтобы итоговая папка была ровно:

`S:\WSL`

После распаковки должна быть такая структура:

```text
S:\WSL\
├─ Backup\
├─ Docs\
├─ Logs\
├─ Toolkit\
└─ VHDX\
```

## 2. Что делать в Windows

Все команды ниже выполняются **в Windows**, из **CMD или PowerShell от имени администратора**.

### Проверка WSL

```cmd
wsl --status
```

Показывает текущее состояние WSL.

```cmd
wsl --version
```

Показывает версию WSL.

```cmd
wsl --list --online
```

Показывает доступные для установки дистрибутивы.

### Варианты установки

```cmd
wsl --install
```

Простейший вариант: установить WSL и дефолтную Ubuntu.

```cmd
wsl --install -d Ubuntu
```

Явная установка Ubuntu.

```cmd
wsl --install -d Ubuntu-24.04
```

Опция: установка Ubuntu 24.04 LTS.

```cmd
wsl --install -d Ubuntu --location "S:\WSL\VHDX\Ubuntu"
```

Рекомендуемый вариант для этого блока: установить Ubuntu сразу в `S:\WSL\VHDX\Ubuntu`.

```cmd
wsl --install -d Ubuntu-24.04 --location "S:\WSL\VHDX\Ubuntu"
```

Опция: установить Ubuntu 24.04 LTS, но папку оставить нейтральной — `S:\WSL\VHDX\Ubuntu`.

После установки Windows может попросить перезагрузку.

### Проверка после установки

```cmd
wsl --update
```

Обновляет сам WSL.

```cmd
wsl --shutdown
```

Полностью останавливает WSL.

```cmd
wsl -l -v
```

Показывает, что Ubuntu установлена и работает на нужной версии WSL.

### Запуск Ubuntu

```cmd
wsl -d Ubuntu
```

Открывает установленную Ubuntu внутри WSL.

## 3. Что делать уже внутри Ubuntu

Ниже — команды **внутри Ubuntu в WSL**, а не в Windows.

```bash
sudo apt update
```

Обновляет индекс пакетов.

```bash
sudo apt upgrade -y
```

Устанавливает обычные обновления.

```bash
sudo apt full-upgrade -y
```

Делает более полный апгрейд пакетов.

```bash
sudo apt autoremove --purge -y
```

Удаляет ненужные пакеты и хвосты.

```bash
sudo apt autoclean
```

Чистит кэш старых пакетов.

```bash
lsb_release -a
```

Показывает версию Ubuntu.

```bash
cat /etc/os-release
```

Альтернативная проверка версии Ubuntu.

```bash
sudo do-release-upgrade
```

Команда для перехода на следующий релиз Ubuntu, когда он станет доступен.

## 4. Что делать через Toolkit

Ниже — операции **снова в Windows**, через host-side toolkit.

### Быстрая проверка

- `Toolkit\RUN_WSL_STATUS.cmd`
- `Toolkit\RUN_WSL_LIST.cmd`
- `Toolkit\RUN_WSL_SHUTDOWN.cmd`

### Backup

- `Toolkit\RUN_WSL_BACKUP_PROMPT.cmd`

Эта команда делает резервную копию дистрибутива.

Результат попадает в:

`S:\WSL\Backup\<DistroName>\`

### Restore from backup

- `Toolkit\RUN_WSL_RESTORE_FROM_BACKUP_PROMPT.cmd`

Эта команда восстанавливает дистрибутив из backup-файла в новую папку под `S:\WSL\VHDX\...`.

### Import existing ext4.vhdx

- `Toolkit\RUN_WSL_IMPORT_IN_PLACE_PROMPT.cmd`

Используется, если у тебя уже есть готовый рабочий `ext4.vhdx`.

### Register all VHDX

- `Toolkit\RUN_WSL_REGISTER_ALL_VHDX.cmd`

Сканирует `S:\WSL\VHDX` и пытается зарегистрировать найденные `ext4.vhdx`.
