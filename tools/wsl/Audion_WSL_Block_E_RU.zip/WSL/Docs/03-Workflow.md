# 03. Типовой сценарий работы (E:\WSL)

## Сценарий 1. Чистая установка WSL и Ubuntu

### В Windows

```cmd
wsl --status
```

Проверка текущего состояния WSL.

```cmd
wsl --version
```

Проверка версии WSL.

```cmd
wsl --list --online
```

Просмотр доступных дистрибутивов.

```cmd
wsl --install -d Ubuntu --location "E:\WSL\VHDX\Ubuntu"
```

Рекомендуемая установка Ubuntu сразу в нужную папку.

```cmd
wsl --update
```

Обновление WSL после установки.

```cmd
wsl -l -v
```

Проверка, что Ubuntu зарегистрирована.

## Сценарий 2. Первичное обновление Ubuntu внутри WSL

### В Windows

```cmd
wsl -d Ubuntu
```

Вход в Ubuntu.

### Внутри Ubuntu

```bash
sudo apt update
```

Обновление индекса пакетов.

```bash
sudo apt upgrade -y
```

Установка обычных обновлений.

```bash
sudo apt full-upgrade -y
```

Полный апгрейд пакетов.

```bash
sudo apt autoremove --purge -y
```

Удаление ненужных пакетов.

```bash
sudo apt autoclean
```

Очистка кэша.

## Сценарий 3. Резервная копия Ubuntu

### Через launcher

- `Toolkit\RUN_WSL_BACKUP_PROMPT.cmd`

### Напрямую через PowerShell

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "E:\WSL\Toolkit\Audion-WSL-Toolkit.ps1" -Action backup -Name Ubuntu -Format vhd
```

Создаёт VHD backup дистрибутива Ubuntu.

## Сценарий 4. Восстановление Ubuntu из backup

### Через launcher

- `Toolkit\RUN_WSL_RESTORE_FROM_BACKUP_PROMPT.cmd`

### Напрямую через PowerShell

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "E:\WSL\Toolkit\Audion-WSL-Toolkit.ps1" -Action restorefrombackup -Name Ubuntu -Location "E:\WSL\VHDX\Ubuntu" -BackupFile "E:\WSL\Backup\Ubuntu\Ubuntu_YYYYMMDD-HHMMSS.vhdx"
```

Восстанавливает Ubuntu из backup-файла в `E:\WSL\VHDX\Ubuntu`.

## Сценарий 5. Регистрация существующего ext4.vhdx

### Через launcher

- `Toolkit\RUN_WSL_IMPORT_IN_PLACE_PROMPT.cmd`

### Напрямую через PowerShell

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "E:\WSL\Toolkit\Audion-WSL-Toolkit.ps1" -Action importinplace -Name Ubuntu -VhdxPath "E:\WSL\VHDX\Ubuntu\ext4.vhdx"
```

Используется, если у тебя уже есть готовый рабочий `ext4.vhdx` и нужно зарегистрировать его как дистрибутив WSL.

## Сценарий 6. Переход на следующий Ubuntu release

### Внутри Ubuntu

```bash
sudo do-release-upgrade
```

Запускает переход на следующий доступный релиз Ubuntu.

## Сценарий 7. Linux bootstrap

Bootstrap `.sh`-скрипты не являются частью WSL-host toolkit.

Их смысл:

- запускать **внутри Ubuntu в WSL**, если ты настраиваешь среду после входа в Linux;
- или запускать на обычной Ubuntu Desktop / Fedora Desktop.

То есть:

- `Toolkit` = операции WSL в Windows
- `bootstrap_*.sh` = настройка Linux-среды внутри самой Linux
