# 02. Структура и смысл папок (E:\WSL)

## Базовая структура

```text
E:\WSL\
├─ Backup\
├─ Docs\
├─ Logs\
├─ Toolkit\
└─ VHDX\
```

## Назначение папок

### `Backup`

Здесь лежат экспортированные резервные копии WSL-дистрибутивов:

```text
E:\WSL\Backup\Ubuntu\Ubuntu_YYYYMMDD-HHMMSS.vhdx
E:\WSL\Backup\Ubuntu\Ubuntu_YYYYMMDD-HHMMSS.tar
```

### `Docs`

Документация по установке, layout и типовым сценариям.

### `Logs`

Логи, которые пишет toolkit при backup / restore / import / scan.

### `Toolkit`

Host-side инструменты для WSL, которые запускаются **в Windows**.

### `VHDX`

Папки с установленными или подготовленными дистрибутивами WSL.

Примеры:

```text
E:\WSL\VHDX\Ubuntu\ext4.vhdx
E:\WSL\VHDX\Fedora\ext4.vhdx
```

## Ключевое разделение

### Это делается в Windows

- `wsl --install ...`
- `wsl --update`
- `wsl --shutdown`
- `wsl -l -v`
- backup / restore / import existing VHDX

### Это делается внутри Ubuntu в WSL

- `sudo apt update`
- `sudo apt upgrade -y`
- `sudo apt full-upgrade -y`
- `sudo do-release-upgrade`
- запуск `.sh` bootstrap-скриптов

### Это отдельный сценарий для Linux Desktop

Если у тебя есть обычная Ubuntu Desktop или Fedora Desktop вне WSL, те же bootstrap `.sh` можно использовать там отдельно. Это не часть структуры `E:\WSL`.

## Важные правила

- Не смешивай `Backup` и живые папки из `VHDX`.
- Лучше держать установленную Ubuntu в `E:\WSL\VHDX\Ubuntu`.
- Лучше не зашивать номер релиза в имя рабочей папки, чтобы при будущем переходе на новый LTS не ломать layout.
- `Register-All-WSL-VHDX.ps1` сканирует именно `E:\WSL\VHDX`, а не весь диск.
