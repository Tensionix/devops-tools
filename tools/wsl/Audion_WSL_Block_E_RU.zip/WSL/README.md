# Audion WSL Block (E:\WSL)

Этот архив нужно распаковать так, чтобы итоговый корень был ровно:

`E:\WSL`

Этот блок предназначен **только для WSL в Windows**.

Он содержит:

- `Backup` — резервные копии дистрибутивов WSL (`.tar`, `.vhd`, `.vhdx`)
- `Docs` — документацию по установке, структуре и сценариям работы
- `Logs` — логи операций toolkit
- `Toolkit` — PowerShell/CMD-утилиты для управления WSL **из Windows**
- `VHDX` — папки с установленными дистрибутивами и их `ext4.vhdx`

## Что относится к Windows / WSL-host

Это делается **в Windows**, из **CMD или PowerShell от имени администратора**:

- установка WSL
- установка Ubuntu в нужную папку
- обновление самого WSL
- просмотр списка дистрибутивов
- backup / restore / import existing VHDX

Основные команды:

```cmd
wsl --status
```

Показывает текущее состояние WSL в Windows.

```cmd
wsl --version
```

Показывает версию WSL.

```cmd
wsl --list --online
```

Показывает список дистрибутивов, которые можно установить.

```cmd
wsl --install
```

Устанавливает WSL и дефолтный дистрибутив Ubuntu.

```cmd
wsl --install -d Ubuntu
```

Явно устанавливает Ubuntu.

```cmd
wsl --install -d Ubuntu-24.04
```

Опция: установить Ubuntu 24.04 LTS, но рабочую папку всё равно лучше держать нейтральной — `Ubuntu`.

```cmd
wsl --install -d Ubuntu --location "E:\WSL\VHDX\Ubuntu"
```

Рекомендуемый вариант для этого блока: установить Ubuntu сразу в `E:\WSL\VHDX\Ubuntu`.

```cmd
wsl --install -d Ubuntu-24.04 --location "E:\WSL\VHDX\Ubuntu"
```

Опция: установить именно Ubuntu 24.04 LTS, но хранить её в стабильной папке `E:\WSL\VHDX\Ubuntu`.

```cmd
wsl --update
```

Обновляет сам WSL в Windows.

```cmd
wsl --shutdown
```

Полностью останавливает WSL.

```cmd
wsl -l -v
```

Показывает установленные дистрибутивы и их версию WSL.

## Что относится к Ubuntu внутри WSL

Это делается **уже после входа в Ubuntu**, внутри Linux:

```cmd
wsl -d Ubuntu
```

Открывает Ubuntu внутри WSL.

Дальше уже команды Linux:

```bash
sudo apt update
```

Обновляет индекс пакетов.

```bash
sudo apt upgrade -y
```

Устанавливает обычные обновления пакетов.

```bash
sudo apt full-upgrade -y
```

Делает более полный апгрейд пакетов с разрешением зависимостей.

```bash
sudo apt autoremove --purge -y
```

Удаляет больше не нужные пакеты и их остатки.

```bash
sudo apt autoclean
```

Очищает локальный кэш старых пакетов.

```bash
lsb_release -a
```

Показывает версию Ubuntu.

```bash
cat /etc/os-release
```

Альтернативная проверка версии Ubuntu.

```bash
sudo do-release-upgrade
```

Используется для перехода с одного релиза Ubuntu на следующий релиз, когда апгрейд станет доступен.

## Что НЕ входит в этот блок

Этот архив **не содержит** Linux bootstrap для Ubuntu Desktop / Fedora Desktop.

Если нужен пакет Linux bootstrap, его лучше держать **отдельно**, например:

- `E:\Audion-Linux-Bootstrap`

или:

- `E:\WSL\Docs\Audion-Linux-Bootstrap`

Но важно понимать смысл:

- этот блок = **WSL в Windows**
- bootstrap `.sh` = **действия внутри Linux** или на обычном Linux Desktop

## Toolkit работает из папки `Toolkit`

PowerShell toolkit использует относительные пути:

- backup по умолчанию идёт в `..\Backup`
- поиск VHDX идёт в `..\VHDX`
- логи пишутся в `..\Logs`

Поэтому один и тот же набор можно класть и в `E:\WSL\Toolkit`, и в аналогичный блок на другом диске.
